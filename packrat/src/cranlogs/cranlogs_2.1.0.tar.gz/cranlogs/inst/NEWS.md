
# 2.1.0

* Query downloads of R: `cran_downloads("R")`.

# 2.0.0

* First release on CRAN.
* Queries return data frames.

# 1.0.0

* First public release.
